import React from "react";

const Button = ({}) => {
  return (
    <button
      type="button"
      className="bg-blue-100 hover:bg-blue-200 text-white font-normal py-3 px-8 shadow-button"
    >
      Request Early Access
    </button>
  );
};

export default Button;
